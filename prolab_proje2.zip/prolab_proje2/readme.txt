190201054-Alperen Tan
180201074-Oğuz Narlı

Projemiz Netbeans 12.1 ortamında Java programlama dilinde Swing kütüphanesi kullanılarak test edilmiştir.

Projenin kurulumu için projenin bulunduğu dosyada bulunan (prolab2\dist\prolab2.jar) JAR dosyasını kullanabilirsiniz.

Kurulum için Netbeans 12.1'de yeni bir proje oluşturduktan sonra projeye sağ tıklayın, Properties kısmını seçtikten sonra 
sol taraftaki panelden Libraries bölümünü seçerek Compile kısmında bulunan Classpath'a belirtilen dosya yolundaki JAR dosyasını ekleyin.
İşlemler bittiğinde projenin altındaki Libraries kısmından projeyi çalıştırabilirsiniz.

